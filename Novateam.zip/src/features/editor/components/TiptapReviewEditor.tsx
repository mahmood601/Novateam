// The review editor itself: loads AI-generated content (already
// converted to Tiptap JSON via novaToTiptap) and lets the team edit it
// like a Word document — no markdown syntax knowledge required.

import {
  onCleanup,
  onMount,
  createSignal,
  createEffect,
  For,
  Match,
  Show,
  Suspense,
  Switch,
} from "solid-js";
import { Editor, JSONContent } from "@tiptap/core";
import { CellSelection } from "@tiptap/pm/tables";
import { Dynamic } from "solid-js/web";
import { DropdownMenu } from "@kobalte/core/dropdown-menu";
import {
  AlignCenter,
  AlignJustify,
  AlignLeft,
  AlignRight,
  AlignVerticalJustifyCenter,
  AlignVerticalJustifyEnd,
  AlignVerticalJustifyStart,
  ArrowLeft,
  Bold,
  CaseSensitive,
  Check,
  CloudCheck,
  CloudOff,
  CloudSync,
  Columns3,
  Copy,
  Eraser,
  FileText,
  Grid2x2Check,
  ImagePlus,
  Images,
  IndentDecrease,
  IndentIncrease,
  Italic,
  Link,
  List,
  ListOrdered,
  Plus,
  Redo2,
  Rows3,
  Save,
  SeparatorHorizontal,
  Strikethrough,
  Table2,
  TableCellsMerge,
  TableProperties,
  Trash2,
  Underline,
  Undo2,
  Workflow,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-solid";

import { debounce } from "@/features/shared/utils/debounce";
import {
  getLecture,
  upsertLecture,
  updateDoctorName,
} from "@/features/shared/services/lecturesUpdates";
import { useUser } from "@/features/shared/context/user";
import { useParams, useNavigate } from "@solidjs/router";

import "../styles/editor.css";
import "../styles/a4-mode.css";
import "../../../../public/print/paged-print.css";
import { extensionsArr } from "../tiptap/extensions/extensionsArr";
import Menu from "./DropdownMenu";
import { useKeyboardToolbar } from "../hooks/usekeyboardToolbar";
import MenuSheet, { type MenuSheetItem } from "./MenuSheet";
import FormatSheet from "./FormatSheet";
import TableGripOverlay from "../tiptap/extensions/table/TableGripOverlay";
import {
  clearSelectedCellsContent,
  duplicateCurrentColumn,
  duplicateCurrentRow,
  findEnclosingCellPos,
  selectCellRange,
  setSelectedCellsAttrs,
} from "../tiptap/extensions/table/tableTransforms";
import type {
  CellTextAlign,
  CellVerticalAlign,
} from "../tiptap/extensions/table/TableCellAttributes";
import { TablePickerPanel } from "../tiptap/extensions/table/TableGridPicker";

export default function TiptapReviewEditor(props: {
  subjectId: string;
  seasonId: string;
}) {
  let containerRef: any;
  let editor: Editor | undefined;
  const { height: vvHeight, top: vvTop } = useKeyboardToolbar();
  const [tick, setTick] = createSignal(0); // forces toolbar re-render on selection/content change

  // ── A4 page mode ───────────────────────────────────────────────
  // A4 is 210mm wide; CSS defines 1in = 96px, so that's ~793.7px.
  const A4_WIDTH_PX = (210 / 25.4) * 96;
  const [a4Active, setA4Active] = createSignal(false);
  // 1 = "fit the phone width"; the +/- buttons multiply on top of that.
  const [a4Scale, setA4Scale] = createSignal(1);

  // Computes the CSS `zoom` that makes the A4 sheet exactly as wide as
  // the screen (never bigger than real size), then applies the user's
  // extra zoom. It's written as a CSS variable that a4-mode.css reads.
  const applyA4Zoom = () => {
    if (!containerRef) return;
    const fit = Math.min(1, (containerRef.clientWidth - 16) / A4_WIDTH_PX);
    const zoom = Math.min(1.5, fit * a4Scale());
    containerRef.style.setProperty("--a4-zoom", String(zoom));
  };

  createEffect(() => {
    // Re-runs whenever A4 mode or the user's zoom changes.
    const active = a4Active();
    a4Scale();
    if (active) applyA4Zoom();
    else containerRef?.style.removeProperty("--a4-zoom");
  });

  const a4ZoomIn = () => setA4Scale((s) => Math.min(3, +(s + 0.35).toFixed(2)));
  const a4ZoomOut = () => setA4Scale((s) => Math.max(1, +(s - 0.35).toFixed(2)));

  // MS Word–style "insert table" grid picker
  const TABLE_PICKER_MAX_ROWS = 8;
  const TABLE_PICKER_MAX_COLS = 10;

  const [insertActive, setInsertActive] = createSignal(false);
  const [formatActive, setFormatActive] = createSignal(false);
  const [tableRowColActive, setTableRowColActive] = createSignal(false);

  // "Select cells" mode: two-tap alternative to drag-to-select, which
  // prosemirror-tables only wires up for mouse `mousedown`+drag and
  // doesn't fire reliably from a touch drag on Android. First tap while
  // active sets the anchor cell; the next tap on a *different* cell
  // builds a rectangular CellSelection between them and turns the mode
  // back off, ready to use (e.g. with the table formatting controls in
  // FormatSheet).
  const [cellSelectActive, setCellSelectActive] = createSignal(false);
  const [cellSelectAnchor, setCellSelectAnchor] = createSignal<number | null>(
    null,
  );

  const params = useParams();
  const subjectId = params.subject ?? "";
  const seasonId = params.season ?? "";
  const navigate = useNavigate();

  const { user } = useUser();
  const [raw, setRaw] = createSignal<JSONContent | null>(null);
  const [status, setStatus] = createSignal<
    "typing" | "saving" | "saved" | "error"
  >("typing");

  const handleFileUpload = (event: Event) => {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        editor?.commands.setContent(content, {
          contentType: "markdown",
          emitUpdate: true,
        });
      };
      setRaw(editor?.getJSON() || null);
      reader.readAsText(file);
    }
  };

  const handleEditDoctorName = async (event: Event) => {
    const newName = window.prompt("ادخل اسم الدكتور :");
    if (newName) {
      await updateDoctorName(
        props.subjectId,
        props.seasonId,
        newName,
        user()?.id,
      );
    }
  };

  const loadLecture = async () => {
    const content = await getLecture({
      subjectId: subjectId,
      seasonId: seasonId,
    });

    const json = content?.data?.[0]?.content?.raw ?? null;
    if (!json) return;

    editor?.commands.setContent(json, {
      contentType: "json",
    });
  };

  const saveToSupabase = async () => {
    setStatus("saving");
    const { error } = await upsertLecture({
      subjectId: props.subjectId,
      seasonId: props.seasonId,
      rawContent: raw(),
      userId: user()?.id,
    });

    if (error) {
      setStatus("error");
    } else {
      setStatus("saved");
      debounce(() => setStatus("typing"), 700)();
    }
  };

  const debounceSave = debounce(saveToSupabase, 1000);

  const handleInputChange = (value: JSONContent) => {
    setStatus("typing");

    if (value !== null) {
      setRaw(value);
      debounceSave();
    }
  };

  const addFigure = () => {
    const url = window.prompt("URL");
    const caption = window.prompt("caption");

    if (url) {
      editor
        ?.chain()
        .focus()
        .setImage({ src: url, caption: caption || "" } as any)
        .run();
    }
  };

  /** Build the insert-menu items. Editor must already exist. */
  const getInsertItems = (): MenuSheetItem[] => [
    {
      id: "image",
      label: "صورة",
      icon: ImagePlus,
      onClick: () => {
        addFigure();
      },
    },
    {
      id: "gallery",
      label: "مجموعة صور",
      icon: Images,
      onClick: () => {
        editor?.commands.setImageGallery();
      },
    },
    {
      id: "mermaid",
      label: "مخطط",
      icon: Workflow,
      onClick: () => {
        editor?.commands.setMermaid();
      },
    },
    {
      id: "table",
      label: "جدول",
      icon: Table2,
      panel: (panelProps) => (
        <TablePickerPanel
          maxRows={TABLE_PICKER_MAX_ROWS}
          maxCols={TABLE_PICKER_MAX_COLS}
          onSelect={(rows, cols) => {
            editor
              ?.chain()
              .focus()
              .insertTable({ rows, cols, withHeaderRow: true })
              .run();
            panelProps.onDone();
          }}
        />
      ),
    },
    {
      id: "box",
      label: "صندوق",
      icon: TableProperties,
      onClick: () => {
        editor?.chain().focus().setBox().run();
      }
    },
    {
      id: "page-break",
      label: "فاصل صفحة",
      icon: SeparatorHorizontal,
      onClick: () => {
        editor?.chain().focus().setPageBreak().run();
        setInsertActive(false);
      },
    },
  ];

  onMount(() => {
    loadLecture();

    // Recompute the A4 fit when the container's width changes (rotation, etc.)
    const a4Observer = new ResizeObserver(() => {
      if (a4Active()) applyA4Zoom();
      // The writing area shrinks when the keyboard or a docked sheet opens:
      // scroll the caret back into view so it is never hidden.
      const sheetOpen =
        insertActive() || formatActive() || tableRowColActive();
      if (editor && (sheetOpen || editor.isFocused)) {
        requestAnimationFrame(() => editor?.commands.scrollIntoView());
      }
    });
    a4Observer.observe(containerRef);
    onCleanup(() => a4Observer.disconnect());

    editor = new Editor({
      element: containerRef,
      content: raw(),
      extensions: [...extensionsArr],
      onTransaction: () => setTick((t) => t + 1),
      onUpdate: ({ editor: e }) => handleInputChange(e.getJSON()),
    });
  });

  onCleanup(() => {
    editor?.destroy();
  });

  const isActive = (name: string) => {
    tick();
    return editor?.isActive(name) ?? false;
  };

  // Drives "select cells" mode: runs on every transaction (which
  // includes plain cursor moves), and only acts while the mode is on.
  createEffect(() => {
    tick();
    if (!cellSelectActive() || !editor) return;

    if (!editor.isActive("table")) {
      // Selection left the table entirely — bail out of the mode rather
      // than leave a stale anchor from a different table.
      setCellSelectActive(false);
      setCellSelectAnchor(null);
      return;
    }

    // Ignore the transaction we ourselves dispatch below when the range
    // is built — it's already a CellSelection, not a fresh tap.
    if (editor.state.selection instanceof CellSelection) return;

    const cellPos = findEnclosingCellPos(editor);
    if (cellPos === null) return;

    const anchor = cellSelectAnchor();
    if (anchor === null) {
      setCellSelectAnchor(cellPos);
      return;
    }
    if (cellPos === anchor) return; // tapped the same cell again, keep waiting

    selectCellRange(editor, anchor, cellPos);
    setCellSelectAnchor(null);
    setCellSelectActive(false);
  });

  const toolbarButtons = [
    {
      icon: Plus,
      title: "Insert",
      activeKey: "insert",
      onClick: () => setInsertActive(!insertActive()),
    },
    {
      icon: CaseSensitive,
      title: "Format",
      activeKey: "format",
      onClick: () => setFormatActive(!formatActive()),
    },
    {
      icon: Bold,
      title: "Bold",
      activeKey: "bold",
      onClick: () => editor?.chain().focus().toggleBold().run(),
    },
    {
      icon: Italic,
      title: "Italic",
      activeKey: "italic",
      onClick: () => editor?.chain().focus().toggleItalic().run(),
    },
    {
      icon: Underline,
      title: "Underline",
      activeKey: "underline",
      onClick: () => editor?.chain().focus().toggleUnderline().run(),
    },
    {
      icon: Link,
      title: "link",
      activeKey: "link",
      onClick: () => {
        const previousUrl = editor?.getAttributes("link").href;
        const url = window.prompt("URL", previousUrl);

        // cancelled
        if (url === null) {
          return;
        }

        // empty
        if (url === "") {
          editor?.chain().focus().extendMarkRange("link").unsetLink().run();

          return;
        }

        // update link
        editor
          ?.chain()
          .focus()
          .extendMarkRange("link")
          .setLink({ href: url })
          .run();
      },
    },
    {
      icon: Strikethrough,
      title: "Strikethrough",
      activeKey: "strike",
      onClick: () => editor?.chain().focus().toggleStrike().run(),
    },
    {
      icon: List,
      title: "Bullet list",
      activeKey: "bulletList",
      onClick: () => editor?.chain().focus().toggleBulletList().run(),
    },
    {
      icon: ListOrdered,
      title: "Numbered list",
      activeKey: "orderedList",
      onClick: () => editor?.chain().focus().toggleOrderedList().run(),
    },
    {
      icon: IndentIncrease,
      title: "Indent (nest list level)",
      activeKey: "indent",
      onClick: () => editor?.chain().focus().liftListItem("listItem").run(),
    },
    {
      icon: IndentDecrease,
      title: "Outdent (lift list level)",
      activeKey: "outdent",
      onClick: () => editor?.chain().focus().sinkListItem("listItem").run(),
    },
  ];

  // Document-level text alignment (heading/paragraph), driven by the
  // @tiptap/extension-text-align extension. Shown as a Kobalte dropdown
  // in the floating toolbar rather than a row of buttons — same package
  // already used for the "⋮" menu in DropdownMenu.tsx.
  const textAlignCommands: {
    icon: any;
    label: string;
    align: "right" | "center" | "left" | "justify";
  }[] = [
    { icon: AlignRight, label: "محاذاة يمين", align: "right" },
    { icon: AlignCenter, label: "محاذاة وسط", align: "center" },
    { icon: AlignLeft, label: "محاذاة يسار", align: "left" },
    { icon: AlignJustify, label: "ضبط", align: "justify" },
  ];

  const isTextAlign = (align: string) => {
    tick();
    return editor?.isActive({ textAlign: align }) ?? false;
  };

  const currentAlignIcon = () =>
    textAlignCommands.find((item) => isTextAlign(item.align))?.icon ??
    AlignRight;

  // Row/column edit commands, shown via a dedicated sheet (see tableRowColActive
  // below) instead of inline in the table context toolbar.
  const tableCommands: MenuSheetItem[] = [
    {
      id: "add-row-before",
      icon: Plus,
      label: "+Row ↑",
      onClick: () => editor?.chain().focus().addRowBefore().run(),
    },
    {
      id: "add-row-after",
      icon: Plus,
      label: "+Row ↓",
      onClick: () => editor?.chain().focus().addRowAfter().run(),
    },
    {
      id: "delete-row",
      icon: Trash2,
      label: "−Row",
      onClick: () => editor?.chain().focus().deleteRow().run(),
    },
    {
      id: "add-col-before",
      icon: Plus,
      label: "+Col ←",
      onClick: () => editor?.chain().focus().addColumnBefore().run(),
    },
    {
      id: "add-col-after",
      icon: Plus,
      label: "+Col →",
      onClick: () => editor?.chain().focus().addColumnAfter().run(),
    },
    {
      id: "delete-col",
      icon: Trash2,
      label: "−Col",
      onClick: () => editor?.chain().focus().deleteColumn().run(),
    },
    {
      id: "merge-split",
      icon: TableCellsMerge,
      label: "Merge/Split",
      onClick: () => editor?.chain().focus().mergeOrSplit().run(),
    },
    {
      id: "duplicate-row",
      icon: Copy,
      label: "Duplicate row",
      onClick: () => editor && duplicateCurrentRow(editor),
    },
    {
      id: "duplicate-col",
      icon: Copy,
      label: "Duplicate col",
      onClick: () => editor && duplicateCurrentColumn(editor),
    },
    {
      id: "clear-content",
      icon: Eraser,
      label: "Clear content",
      onClick: () => editor && clearSelectedCellsContent(editor),
    },
    {
      id: "header-row",
      icon: Rows3,
      label: "Header row",
      onClick: () => editor?.chain().focus().toggleHeaderRow().run(),
    },
    {
      id: "header-col",
      icon: Columns3,
      label: "Header col",
      onClick: () => editor?.chain().focus().toggleHeaderColumn().run(),
    },
    {
      id: "header-cell",
      icon: TableProperties,
      label: "Header cell",
      onClick: () => editor?.chain().focus().toggleHeaderCell().run(),
    },
    {
      id: "delete-table",
      icon: Trash2,
      label: "Delete Table",
      onClick: () => editor?.chain().focus().deleteTable().run(),
    },
  ];

  const cellAlignCommands: {
    icon: any;
    title: string;
    align: CellTextAlign;
  }[] = [
    { icon: AlignLeft, title: "Align left", align: "left" },
    { icon: AlignCenter, title: "Align center", align: "center" },
    { icon: AlignRight, title: "Align right", align: "right" },
    { icon: AlignJustify, title: "Justify", align: "justify" },
  ];

  const cellVerticalAlignCommands: {
    icon: any;
    title: string;
    align: CellVerticalAlign;
  }[] = [
    { icon: AlignVerticalJustifyStart, title: "Align top", align: "top" },
    {
      icon: AlignVerticalJustifyCenter,
      title: "Align middle",
      align: "middle",
    },
    { icon: AlignVerticalJustifyEnd, title: "Align bottom", align: "bottom" },
  ];

  return (
    // Root is pinned to the visual viewport (area above the keyboard).
    // Everything inside is a normal flex column: header / writing area /
    // bottom dock. Nothing floats over the text any more.
    <div
      style={{ height: `${vvHeight()}px`, top: `${vvTop()}px` }}
      class="bg-main-light dark:bg-main-dark fixed left-0 flex w-full flex-col overflow-hidden"
    >
      <EditorHeader
        seasonId={seasonId}
        status={status}
        onBack={() => navigate(-1)}
        onSave={saveToSupabase}
        onUndo={() => editor?.chain().focus().undo().run()}
        onRedo={() => editor?.chain().focus().redo().run()}
        a4Active={a4Active()}
        onToggleA4={() => setA4Active((v) => !v)}
        subjectId={props.subjectId}
        handleFileUpload={handleFileUpload}
        handleEditDoctorName={handleEditDoctorName}
      />

      <div
        class="nova-tiptap-review relative flex min-h-0 w-full flex-1 flex-col"
        dir="rtl"
      >
        <Suspense fallback={<div>Loading...</div>}>
          <div
            ref={containerRef}
            class="nova-tiptap-content dark:bg-main-dark dark:text-main-light min-h-0 flex-1 overflow-auto"
            classList={{ "a4-mode": a4Active() }}
          />
        </Suspense>

        {/* A4 mode: hint + zoom controls */}
        <Show when={a4Active()}>
          <div class="pointer-events-none absolute inset-x-0 top-2 z-40 flex justify-center">
            <span class="bg-main rounded-full px-3 py-1 text-xs text-white shadow">
              A4 · الشريط الرمادي = فاصل الصفحة
            </span>
          </div>
          <div class="bg-main-light dark:bg-lighter-dark-1 absolute top-12 left-2 z-40 flex flex-col gap-1 rounded-xl p-1 shadow-md">
            <button class="rounded p-2" title="تكبير" onClick={a4ZoomIn}>
              <ZoomIn size={18} />
            </button>
            <button class="rounded p-2" title="تصغير" onClick={a4ZoomOut}>
              <ZoomOut size={18} />
            </button>
          </div>
        </Show>

        {/* Row/column grip overlay: drag to reorder, tap to select */}
        <TableGripOverlay
          editor={() => editor}
          tick={tick}
          visible={() =>
            !insertActive() && !formatActive() && !tableRowColActive()
          }
        />
      </div>

      {/* Bottom dock: toolbar and sheets live IN the layout (shrink-0), so
          the writing area above is resized instead of being covered. */}
      <div class="bg-main-light dark:bg-lighter-dark-1 z-50 flex w-full shrink-0 flex-col shadow-[0_-1px_6px_rgb(0_0_0/0.12)]">
        {/* Hint shown while waiting for the second tap in "select cells" mode */}
        <Show when={cellSelectActive() && cellSelectAnchor() !== null}>
          <div
            style={{ "background-color": "var(--color-main)" }}
            class="self-center rounded-full px-3 py-1 text-xs text-white"
          >
            اضغط الخلية الثانية لإتمام التحديد
          </div>
        </Show>

        {/* Table context row: cell alignment */}
        <Show when={isActive("table")}>
          <div class="flex items-center justify-center gap-1 px-3 py-1 text-xs">
            <For each={cellAlignCommands}>
              {(item) => (
                <button
                  type="button"
                  class="rounded p-1.5 hover:opacity-80"
                  title={item.title}
                  style={{
                    "background-color": "var(--editor-chrome-bg)",
                    color: "var(--editor-chrome-icon)",
                  }}
                  onClick={() =>
                    editor &&
                    setSelectedCellsAttrs(editor, { textAlign: item.align })
                  }
                >
                  <item.icon size={14} />
                </button>
              )}
            </For>

            <For each={cellVerticalAlignCommands}>
              {(item) => (
                <button
                  type="button"
                  class="rounded p-1.5 hover:opacity-80"
                  title={item.title}
                  style={{
                    "background-color": "var(--editor-chrome-bg)",
                    color: "var(--editor-chrome-icon)",
                  }}
                  onClick={() =>
                    editor &&
                    setSelectedCellsAttrs(editor, { verticalAlign: item.align })
                  }
                >
                  <item.icon size={14} />
                </button>
              )}
            </For>
          </div>
        </Show>

        {/* Formatting toolbar (replaced by a sheet while one is open) */}
        <Show when={!insertActive() && !formatActive() && !tableRowColActive()}>
          <div class="flex w-full flex-row gap-2 overflow-x-auto px-3 py-2">
            <For each={toolbarButtons}>
              {(button) => (
                <button
                  type="button"
                  class="hover:bg-darker-light-1 dark:hover:bg-lighter-dark-2 shrink-0 rounded p-2"
                  title={button.title}
                  classList={{ active: isActive(button.activeKey) }}
                  onClick={button.onClick}
                >
                  <button.icon size={18} />
                </button>
              )}
            </For>

            {/* Text alignment (heading/paragraph) — Kobalte dropdown */}
            <DropdownMenu>
              <DropdownMenu.Trigger
                type="button"
                class="hover:bg-darker-light-1 dark:hover:bg-lighter-dark-2 shrink-0 rounded p-2"
                title="Text alignment"
              >
                <Dynamic component={currentAlignIcon()} size={18} />
              </DropdownMenu.Trigger>
              <DropdownMenu.Portal>
                <DropdownMenu.Content
                  class="border-darker-light-2 dark:border-lighter-dark-2 bg-main-light dark:bg-lighter-dark-1 text-header dark:text-main-light z-50 min-w-40 rounded-lg border p-1 shadow-lg"
                  dir="rtl"
                >
                  <For each={textAlignCommands}>
                    {(item) => (
                      <DropdownMenu.Item
                        class="hover:bg-darker-light-1 dark:hover:bg-lighter-dark-2 focus:bg-darker-light-1 dark:focus:bg-lighter-dark-2 flex cursor-pointer list-none items-center gap-2 rounded-md px-3 py-2 text-right text-sm outline-none"
                        onSelect={() =>
                          editor
                            ?.chain()
                            .focus()
                            .toggleTextAlign(item.align)
                            .run()
                        }
                      >
                        <item.icon size={16} />
                        <span class="flex-1">{item.label}</span>
                        <Show when={isTextAlign(item.align)}>
                          <Check
                            size={14}
                            style={{ color: "var(--color-main)" }}
                          />
                        </Show>
                      </DropdownMenu.Item>
                    )}
                  </For>
                </DropdownMenu.Content>
              </DropdownMenu.Portal>
            </DropdownMenu>

            {/* Only shown while the selection is inside a table */}
            <Show when={isActive("table")}>
              <button
                type="button"
                class="hover:bg-darker-light-1 dark:hover:bg-lighter-dark-2 shrink-0 rounded p-2"
                title={
                  cellSelectAnchor() !== null
                    ? "اضغط الخلية الثانية"
                    : "تحديد خليتين متجاورتين"
                }
                classList={{ active: cellSelectActive() }}
                onClick={() => {
                  const next = !cellSelectActive();
                  setCellSelectActive(next);
                  setCellSelectAnchor(null);
                }}
              >
                <Grid2x2Check size={18} />
              </button>
              <button
                type="button"
                class="hover:bg-darker-light-1 dark:hover:bg-lighter-dark-2 shrink-0 rounded p-2"
                title="Rows & columns"
                classList={{ active: tableRowColActive() }}
                onClick={() => setTableRowColActive(!tableRowColActive())}
              >
                <TableProperties size={18} />
              </button>
            </Show>
          </div>
        </Show>

        {/* Insert sheet */}
        <Show when={insertActive()}>
          <div class="flex max-h-[45dvh] w-full flex-col overflow-hidden pb-1">
            <MenuSheet
              title="ادراج"
              onClose={() => setInsertActive(false)}
              items={getInsertItems()}
            />
          </div>
        </Show>

        {/* Rows/columns sheet */}
        <Show when={tableRowColActive()}>
          <div class="flex max-h-[45dvh] w-full flex-col overflow-hidden pb-1">
            <MenuSheet
              title="صفوف وأعمدة"
              onClose={() => setTableRowColActive(false)}
              items={tableCommands}
            />
          </div>
        </Show>

        {/* "Aa" format sheet */}
        <Show when={formatActive()}>
          <div class="flex max-h-[45dvh] w-full flex-col overflow-hidden pb-1">
            <FormatSheet
              editor={() => editor}
              tick={tick}
              onClose={() => setFormatActive(false)}
            />
          </div>
        </Show>
      </div>
    </div>
  );
}

function EditorHeader(props: {
  seasonId: string;
  status: () => "typing" | "saving" | "saved" | "error";
  onBack: () => void;
  onSave: () => void;
  onUndo: () => void;
  onRedo: () => void;
  a4Active: boolean;
  onToggleA4: () => void;
  subjectId: string;
  handleFileUpload: (event: Event) => void;
  handleEditDoctorName: (event: Event) => void;
}) {
  return (
    <div class="border-darker-light-2 dark:border-lighter-dark-2 bg-main-light dark:bg-main-dark relative z-50 w-full shrink-0 border-b shadow-sm">
      <div class="mx-auto flex max-w-6xl items-center gap-3 px-4 py-2">
        <button
          class="hover:bg-darker-light-1 dark:hover:bg-lighter-dark-2 flex items-center rounded p-2"
          title="Back"
          onClick={props.onBack}
        >
          <ArrowLeft size={20} />
        </button>

        <div class="text-header dark:text-main-light flex-1 text-center text-[18px] font-medium">
          <span>{props.seasonId}</span>
        </div>

        <div class="flex items-center gap-2">
          <div
            class="cursor-pointer rounded p-1"
            title="Save"
            onClick={props.onSave}
          >
            <Switch>
              <Match when={props.status() == "typing"}>
                <Save size={18} />
              </Match>
              <Match when={props.status() == "saving"}>
                <CloudSync size={18} />
              </Match>
              <Match when={props.status() == "saved"}>
                <CloudCheck class="text-green-700" size={18} />
              </Match>
              <Match when={props.status() == "error"}>
                <CloudOff class="text-red-700" size={18} />
              </Match>
            </Switch>
          </div>

          <button
            class="hover:bg-darker-light-1 dark:hover:bg-lighter-dark-2 rounded-full p-2"
            title="Undo"
            onClick={props.onUndo}
          >
            <Undo2 size={20} />
          </button>
          <button
            class="hover:bg-darker-light-1 dark:hover:bg-lighter-dark-2 rounded-full p-2"
            title="Redo"
            onClick={props.onRedo}
          >
            <Redo2 size={20} />
          </button>

          <button
            class="hover:bg-darker-light-1 dark:hover:bg-lighter-dark-2 rounded-full p-2"
            classList={{ "bg-main/15 text-main": props.a4Active }}
            title="A4"
            onClick={props.onToggleA4}
          >
            <FileText size={20} />
          </button>

          <Menu
            subjectId={props.subjectId}
            seasonId={props.seasonId}
            handleFileUpload={props.handleFileUpload}
            handleEditDoctorName={props.handleEditDoctorName}
          />
        </div>
      </div>
    </div>
  );
}