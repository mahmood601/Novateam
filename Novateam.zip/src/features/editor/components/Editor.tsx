import { EditorToolbar } from "./EditorToolbar";
import { EditorSidebar } from "./EditorSidebar";
import { EditorOutline } from "./EditorOutline";

export function Editor() {
  return (
    <div class="flex h-full flex-col">
      {/* Top bar */}
      <EditorToolbar />

      {/* Main editor area */}
      <div class="flex min-h-0 flex-1">
        {/* Left sidebar */}
        <EditorSidebar />

        {/* Document */}
        <main class="min-w-0 flex-1 overflow-auto">
          <div class="mx-auto max-w-4xl px-6 py-10">
            <article
              class="
                min-h-[calc(100vh-8rem)]
                rounded-2xl
                bg-white
                px-8 py-10
                shadow-sm
                ring-1 ring-slate-200
                dark:bg-slate-900
                dark:ring-slate-800
              "
            >
              <EditorOutline />
            </article>
          </div>
        </main>
      </div>
    </div>
  );
}