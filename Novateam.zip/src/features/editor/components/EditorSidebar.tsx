import { For } from "solid-js";

const sections = [
  {
    title: "المناعة الفطرية",
    color: "bg-[#D00054]",
  },
  {
    title: "المناعة المكتسبة",
    color: "bg-[#FF9933]",
  },
  {
    title: "المتممة",
    color: "bg-[#BF8F00]",
  },
  {
    title: "الخلايا B",
    color: "bg-[#00B050]",
  },
  {
    title: "الخلايا T",
    color: "bg-[#3399FF]",
  },
];

export function EditorSidebar() {
  return (
    <aside
      class="
        hidden w-64 shrink-0
        border-e border-slate-200
        bg-slate-50
        dark:border-slate-800
        dark:bg-slate-950
        md:block
      "
    >
      <div class="flex h-full flex-col">
        {/* Sidebar header */}
        <div class="flex h-12 items-center px-4">
          <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Outline
          </span>
        </div>

        {/* Sections */}
        <nav class="flex-1 overflow-y-auto px-2">
          <For each={sections}>
            {(section) => (
              <button
                class="
                  group flex w-full items-center gap-3
                  rounded-lg px-3 py-2
                  text-start text-sm
                  text-slate-600
                  transition
                  hover:bg-slate-200/70
                  hover:text-slate-900
                  dark:text-slate-400
                  dark:hover:bg-slate-900
                  dark:hover:text-white
                "
              >
                <span
                  class={`h-2.5 w-2.5 shrink-0 rounded-full ${section.color}`}
                />

                <span class="truncate">
                  {section.title}
                </span>
              </button>
            )}
          </For>
        </nav>
      </div>
    </aside>
  );
}