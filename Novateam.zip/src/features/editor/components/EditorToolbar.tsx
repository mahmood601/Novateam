export function EditorToolbar() {
  return (
    <header
      class="
        flex h-14 shrink-0 items-center
        border-b border-slate-200
        bg-white/90 px-4
        backdrop-blur
        dark:border-slate-800
        dark:bg-slate-950/90
      "
    >
      {/* Left */}
      <div class="flex items-center gap-3">
        <button
          class="
            flex h-9 w-9 items-center justify-center
            rounded-lg
            text-slate-500
            hover:bg-slate-100
            hover:text-slate-900
            dark:hover:bg-slate-900
            dark:hover:text-white
          "
          aria-label="Toggle sidebar"
        >
          ☰
        </button>

        <div>
          <div class="text-sm font-semibold">
            Nova
          </div>

          <div class="text-xs text-slate-500">
            Editor
          </div>
        </div>
      </div>

      {/* Center */}
      <div class="mx-auto hidden text-sm text-slate-500 sm:block">
        المناعة
      </div>

      {/* Right */}
      <div class="flex items-center gap-2">
        <span class="hidden text-xs text-slate-400 sm:block">
          Saved
        </span>

        <button
          class="
            flex h-9 w-9 items-center justify-center
            rounded-lg
            text-slate-500
            hover:bg-slate-100
            dark:hover:bg-slate-900
          "
          aria-label="More"
        >
          ⋮
        </button>
      </div>
    </header>
  );
}