export function EditorOutline() {
  return (
    <div dir="rtl" class="prose prose-slate max-w-none dark:prose-invert">
      {/* Title */}

      <header class="mb-10">
        <div class="mb-3 h-1 w-20 rounded-full bg-[#D00054]" />

        <h1 class="m-0 text-4xl font-bold tracking-tight">
          المناعة
        </h1>

        <p class="mt-3 text-sm text-slate-500">
          محاضرة المناعة — السنة الثالثة
        </p>
      </header>

      {/* Section */}

      <section>
        <div class="mb-5 flex items-center gap-3">
          <span class="h-8 w-1 rounded-full bg-[#D00054]" />

          <h2 class="m-0 text-2xl font-bold">
            المناعة الفطرية
          </h2>
        </div>

        <p class="leading-8 text-slate-700 dark:text-slate-300">
          تشكل المناعة الفطرية خط الدفاع الأول ضد العوامل الممرضة،
          وتتميز بسرعة الاستجابة وعدم اعتمادها على التعرض السابق
          للمستضد.
        </p>

        <h3 class="mt-8 text-xl font-semibold">
          الحواجز الفيزيائية
        </h3>

        <p class="leading-8 text-slate-700 dark:text-slate-300">
          يشكل الجلد والأغشية المخاطية حاجزًا مهمًا يمنع دخول
          العديد من الكائنات الممرضة.
        </p>

        <h3 class="mt-8 text-xl font-semibold">
          العدلات
        </h3>

        <p class="leading-8 text-slate-700 dark:text-slate-300">
          تعد العدلات من أهم الخلايا المشاركة في الاستجابة
          المناعية الفطرية.
        </p>
      </section>

      {/* Second section */}

      <section class="mt-14">
        <div class="mb-5 flex items-center gap-3">
          <span class="h-8 w-1 rounded-full bg-[#FF9933]" />

          <h2 class="m-0 text-2xl font-bold">
            المناعة المكتسبة
          </h2>
        </div>

        <p class="leading-8 text-slate-700 dark:text-slate-300">
          تتميز المناعة المكتسبة بخصوصيتها للمستضد وبوجود ذاكرة
          مناعية.
        </p>
      </section>
    </div>
  );
}