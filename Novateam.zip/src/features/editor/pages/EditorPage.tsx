import { Editor } from "../components/Editor";

export default function EditorPage() {
  return (
    <div class="h-screen w-full overflow-hidden bg-slate-100 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <Editor />
    </div>
  );
}