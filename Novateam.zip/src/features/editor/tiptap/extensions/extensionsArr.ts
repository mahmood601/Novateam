import TableRow from "@tiptap/extension-table-row";
import { NovaTableCell, NovaTableHeader } from "./table/TableCellAttributes";
import { Markdown } from "@tiptap/markdown";
import StarterKit from "@tiptap/starter-kit";
import { TextStyleKit } from "@tiptap/extension-text-style";
import TextAlign from "@tiptap/extension-text-align";
import Highlight from "@tiptap/extension-highlight";
import Subscript from "@tiptap/extension-subscript";
import Superscript from "@tiptap/extension-superscript";
import { Diagram } from "./diagram";
import { NovaAdmonition } from "./NovaAdmonition";
import { NovaCards } from "./NovaCards";
import {
  NovaCase,
  NovaChips,
  NovaCompare,
  NovaSteps,
  NovaSummary,
} from "./NovaShapes";
import { NovaHeading } from "./NovaHeadingExtension";
import { NovaQuiz } from "./NovaQuiz";
import { NovaPageBreak } from "./NovaPageBreak";
import Link from "@tiptap/extension-link";
import { FindAndReplace } from "@tiptap/extension-find-and-replace";
import { ImageWithCaption } from "./ImageWithCaption";
import NovaImageGallery from "./NovaImageGallery";
import { NovaBox } from "./NovaBox";
import { NovaTable } from "./table/novaTable";
import { TableTouchResize } from "./table/TableTouchResize";
import { NovaBulletList } from "./NovaBulletList";
import { NovaClipboard } from "./NovaClipboard";
import { NovaSectionTokens } from "./NovaSectionTokens";

// Sub/superscript don't exclude each other by default, which lets both
// marks stack on the same text and render nonsense nested offsets — so
// each one explicitly excludes the other, matching how Word/Docs behave.
const NovaSubscript = Subscript.extend({ excludes: "superscript" });
const NovaSuperscript = Superscript.extend({ excludes: "subscript" });

export const extensionsArr = [
  // Highlight styles live in editor.css (injectCSS off) so they follow the theme.
  FindAndReplace.configure({ injectCSS: false, searchDebounceMs: 150 }),
  StarterKit.configure({
    heading: false,
    link: false,
    bulletList: false,
    // Smaller undo steps (default 500ms merged long typing bursts into one).
    undoRedo: { newGroupDelay: 250 },
  }), // replaced by NovaHeading/Link below
  NovaHeading,
  NovaBulletList,
  NovaAdmonition,
  NovaCards,
  NovaSteps,
  NovaCompare,
  NovaChips,
  NovaCase,
  NovaSummary,
  NovaQuiz,
  NovaPageBreak,
  TextStyleKit.configure({ lineHeight: false }), // color, backgroundColor, fontFamily, fontSize
  TextAlign.configure({ types: ["heading", "paragraph"] }),
  Highlight.configure({ multicolor: true, HTMLAttributes: { class: "highlight" } }),
  NovaSubscript,
  NovaSuperscript,
  Diagram.configure({
    debounceMs: 400,
  }),
  // Table nodes are wired up individually (rather than via TableKit) so
  // TableCell/TableHeader can be swapped for the alignment-aware variants
  // below. Column resizing is done by TableTouchResize (finger AND mouse),
  // so `handleWidth: 0` keeps prosemirror-tables' own resize from starting
  // (its mouse drag briefly changed the table's width and is LTR-only).
  NovaTable.configure({
    resizable: true,
    lastColumnResizable: true,
    allowTableNodeSelection: true,
    handleWidth: 0,
    cellMinWidth: 40,
  }),
  TableTouchResize,
  TableRow,
  NovaTableHeader,
  NovaTableCell,
  ImageWithCaption.configure({
    inline: true,
    HTMLAttributes: {
      class: "lecture-image",
      "data-resize-wrapper": "true",
      allowBase64: false,
    },
    // Tiptap's built-in resizer is mouse-only, so it is OFF. Resizing (finger
    // and mouse) is done by ImageGripOverlay, which saves `widthPct`.
  }),
  NovaImageGallery,
  NovaBox,
  // Lossless cut/copy/paste inside the editor (see NovaClipboard.ts).
  NovaClipboard,
  // View-only: data-color on plain blocks so "section color" manual colors resolve.
  NovaSectionTokens,
  Link.configure({
    openOnClick: false,
    markdownLinks: true,
    defaultProtocol: "https",
  }),
  Markdown.configure({
    indentation: {
      style: "space", // 'space' or 'tab'
      size: 2, // Number of spaces or tabs
    },
  }),
];