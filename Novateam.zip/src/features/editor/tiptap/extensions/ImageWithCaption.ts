import { mergeAttributes } from "@tiptap/core";
import Image from "@tiptap/extension-image";

export const ImageWithCaption = Image.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      caption: { default: null },
      align: {
        default: null, // null = leave as-is
        parseHTML: (el: HTMLElement) =>
          el.getAttribute("data-align") ||
          el.parentElement?.getAttribute("data-align") || // captioned wrapper
          null,
        renderHTML: () => ({}), // rendered manually below
      },
    };
  },

  renderHTML(props: any) {
    const { HTMLAttributes, node } = props;
    const { caption, ...attrs } = HTMLAttributes;
    const align = node.attrs.align;

    const img = [
      "img",
      mergeAttributes(
        this.options.HTMLAttributes,
        attrs,
        !caption && align ? { "data-align": align } : {},
      ),
    ];

    if (!caption) return img;

    return [
      "div",
      {
        class: "image-with-caption",
        ...(align ? { "data-align": align } : {}),
      },
      img,
      ["div", { class: "image-caption" }, caption],
    ];
  },

  // @ts-ignore - custom node view matches runtime behavior, but official typings are narrower
  addNodeView() {
    return (props: any) => {
      const parentView = this.parent?.();
      if (!parentView) return null;

      const view = parentView(props);
      const applyAlign = (node: any) => {
        const el = view.dom as HTMLElement;
        if (node.attrs.align) el.setAttribute("data-align", node.attrs.align);
        else el.removeAttribute("data-align");
      };
      applyAlign(props.node);

      const cap = document.createElement("div");
      cap.textContent = props.node.attrs.caption ?? "";
      cap.classList.add("image-caption");
      cap.contentEditable = "true";

      cap.addEventListener("blur", () => {
        const pos = props.getPos();
        if (typeof pos !== "number") return;
        const text = (cap.textContent ?? "").trim();
        props.editor.commands.command(({ tr }: any) => {
          tr.setNodeMarkup(pos, undefined, {
            ...props.editor.state.doc.nodeAt(pos)?.attrs,
            caption: text || null,
          });
          return true;
        });
      });

      (view.dom as HTMLElement).appendChild(cap);

      return {
        dom: view.dom,
        update: (node: any, decorations: any, inner: any) => {
          applyAlign(node);
          if (document.activeElement !== cap) {
            cap.textContent = node.attrs.caption ?? "";
          }
          return view.update?.(node, decorations, inner) ?? true;
        },
        destroy: () => view.destroy?.(),
        ignoreMutation: (m: any) =>
          cap.contains(m.target as Node) || (view.ignoreMutation?.(m) ?? false),
        stopEvent: (e: any) =>
          cap.contains(e.target as Node) || (view.stopEvent?.(e) ?? false),
      };
    };
  },
});
