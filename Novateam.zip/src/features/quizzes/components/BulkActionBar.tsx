import { createSignal, For, Show } from "solid-js";
import toast from "solid-toast";
import { supabase } from "../../shared/services/supabase";
import type { Section } from "../services/types";
import { setQuestionsStatus } from "../services/questions";
import { useUser } from "../../shared/context/user";

export function BulkActionBar(props: {
  selectedIds: Set<string>;
  sections: Section[];
  subjectId: string;
  onClear: () => void;
  onComplete: () => void;
}) {
  const { can } = useUser();
  const canMove = () => can("quiz", props.subjectId, "publish");
  // Publishing needs the same level as moving; Postgres re-checks it anyway.
  const canPublish = () => can("quiz", props.subjectId, "publish");
  const canDelete = () => can("quiz", props.subjectId, "manage");

  const [moving, setMoving] = createSignal(false);
  const [targetSeasonId, setTargetSeasonId] = createSignal<number | null>(null);
  const [targetYearId, setTargetYearId] = createSignal<number | null>(null);
  const [showPanel, setShowPanel] = createSignal(false);

  const count = () => props.selectedIds.size;

  const handleMove = async () => {
    if (!targetSeasonId() && !targetYearId()) {
      toast.error("اختر فصلاً أو سنة للنقل إليها");
      return;
    }

    setMoving(true);
    const ids = [...props.selectedIds];
    const updates: any = {};
    if (targetSeasonId()) updates.season_id = targetSeasonId();
    if (targetYearId()) updates.year_id = targetYearId();

    // .select("id") returns the rows that REALLY changed. RLS silently skips
    // rows you may not touch (no error!), so we compare against what we asked.
    const { data: rows, error } = await supabase
      .from("questions")
      .update(updates)
      .in("id", ids)
      .eq("subject_id", props.subjectId)
      .select("id");

    setMoving(false);

    if (error) {
      toast.error("فشل النقل: " + error.message);
      return;
    }

    const done = rows?.length ?? 0;
    if (done === 0) {
      toast.error("لا تملك صلاحية نقل هذه الأسئلة");
      return;
    }
    if (done < ids.length) {
      toast.error(`نُقل ${done} من ${ids.length} فقط — لا تملك صلاحية الباقي`);
    } else {
      toast.success(`تم نقل ${done} سؤال ✅`);
    }
    props.onClear();
    props.onComplete();
    setShowPanel(false);
  };

  // Bulk publish / unpublish for every selected question (any page, any filter).
  const handleStatus = async (next: "published" | "pending") => {
    const ids = [...props.selectedIds];
    if (
      next === "pending" &&
      !confirm(`إلغاء نشر ${ids.length} سؤال؟ ستختفي عن الطلاب.`)
    ) {
      return;
    }

    setMoving(true);
    const { count: done, error } = await setQuestionsStatus(
      ids,
      props.subjectId,
      next,
    );
    setMoving(false);

    if (error) {
      toast.error("فشل التحديث: " + error);
      return;
    }
    if (done === 0) {
      toast.error("لا تملك صلاحية على هذه الأسئلة");
      return;
    }
    const verb = next === "published" ? "نُشر" : "أُلغي نشر";
    if (done < ids.length) {
      toast.error(`${verb} ${done} من ${ids.length} فقط — لا تملك صلاحية الباقي`);
    } else {
      toast.success(`${verb} ${done} سؤال ✅`);
    }
    props.onClear();
    props.onComplete();
  };

  const handleDelete = async () => {
    if (!confirm(`هل تريد حذف ${count()} سؤال محدد؟ لا يمكن التراجع!`)) return;

    setMoving(true);
    const ids = [...props.selectedIds];
    const { data: rows, error } = await supabase
      .from("questions")
      .delete()
      .in("id", ids)
      .eq("subject_id", props.subjectId)
      .select("id");

    setMoving(false);

    if (error) {
      toast.error("فشل الحذف: " + error.message);
      return;
    }

    const done = rows?.length ?? 0;
    if (done === 0) {
      toast.error("لا تملك صلاحية حذف هذه الأسئلة");
      return;
    }
    if (done < ids.length) {
      toast.error(`حُذف ${done} من ${ids.length} فقط — لا تملك صلاحية الباقي`);
    } else {
      toast.success(`تم حذف ${done} سؤال 🗑️`);
    }
    props.onClear();
    props.onComplete();
  };

  return (
    <div class="fixed bottom-6 left-1/2 z-50 w-[calc(100%-2rem)] max-w-lg -translate-x-1/2" dir="rtl">
      <div class="flex flex-wrap items-center gap-2 rounded-[2rem] bg-slate-900 p-4 text-white shadow-2xl">
        <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-cyan-500 text-sm font-black">
          {count()}
        </span>
        <span class="flex-1 text-sm font-bold">سؤال محدد</span>

        <Show when={canPublish()}>
          <button
            onClick={() => handleStatus("published")}
            disabled={moving()}
            class="rounded-xl bg-green-500 px-3 py-2 text-sm font-bold transition hover:bg-green-400 disabled:opacity-50"
          >
            نشر ✓
          </button>
          <button
            onClick={() => handleStatus("pending")}
            disabled={moving()}
            class="rounded-xl bg-slate-600 px-3 py-2 text-sm font-bold transition hover:bg-slate-500 disabled:opacity-50"
          >
            إلغاء النشر
          </button>
        </Show>
        <Show when={canMove()}>
          <button
            onClick={() => setShowPanel(!showPanel())}
            class="rounded-xl bg-cyan-500 px-4 py-2 text-sm font-bold transition hover:bg-cyan-400"
          >
            نقل 📦
          </button>
        </Show>
        <Show when={canDelete()}>
          <button
            onClick={handleDelete}
            disabled={moving()}
            class="rounded-xl bg-red-500 px-4 py-2 text-sm font-bold transition hover:bg-red-400 disabled:opacity-50"
          >
            حذف 🗑️
          </button>
        </Show>
        <button
          onClick={props.onClear}
          class="rounded-xl bg-slate-700 px-3 py-2 text-sm font-bold transition hover:bg-slate-600"
        >
          ✕
        </button>
      </div>

      <Show when={showPanel()}>
        <div class="mt-2 rounded-[2rem] bg-surface-light p-5 shadow-2xl dark:bg-surface-dark">
          <p class="mb-3 text-sm font-bold text-ink-soft-light dark:text-ink-soft-dark">
            نقل {count()} سؤال إلى:
          </p>
          <div class="mb-4 grid grid-cols-2 gap-3">
            <div class="flex flex-col gap-1">
              <label class="text-xs font-bold text-ink-soft-light">الفصل</label>
              <select
                class="rounded-2xl bg-base-light p-3 text-sm outline-none focus:ring-2 focus:ring-cyan-300 dark:bg-base-dark dark:text-ink-dark"
                onChange={(e) =>
                  setTargetSeasonId(e.currentTarget.value ? Number(e.currentTarget.value) : null)
                }
              >
                <option value="">بدون تغيير</option>
                <For each={props.sections.filter((s) => s.type === "season")}>
                  {(s) => <option value={s.id}>{s.name}</option>}
                </For>
              </select>
            </div>
            <div class="flex flex-col gap-1">
              <label class="text-xs font-bold text-ink-soft-light">السنة</label>
              <select
                class="rounded-2xl bg-base-light p-3 text-sm outline-none focus:ring-2 focus:ring-cyan-300 dark:bg-base-dark dark:text-ink-dark"
                onChange={(e) =>
                  setTargetYearId(e.currentTarget.value ? Number(e.currentTarget.value) : null)
                }
              >
                <option value="">بدون تغيير</option>
                <For each={props.sections.filter((s) => s.type === "year")}>
                  {(y) => <option value={y.id}>{y.name}</option>}
                </For>
              </select>
            </div>
          </div>
          <button
            onClick={handleMove}
            disabled={moving() || (!targetSeasonId() && !targetYearId())}
            class="w-full rounded-2xl bg-gradient-to-r from-cyan-400 to-blue-500 py-3 font-black text-white shadow-lg transition disabled:opacity-50"
          >
            {moving() ? "جاري النقل..." : `نقل ${count()} سؤال ✅`}
          </button>
        </div>
      </Show>
    </div>
  );
}
