import { createEffect, createSignal, onCleanup, onMount, Show } from "solid-js";
import {
  addFavoriteForQuestion,
  removeFavorite,
  updateFavoriteNote,
  getFavorite,
} from "../services/local/indexeddb";
import toast from "solid-toast";

export default function FavoriteButton(props: any) {
  const [active, setActive] = createSignal(false);
  const [note, setNote] = createSignal<string | undefined>(undefined);

  let mounted = true;
  onMount(() => {
    mounted = true;
  });
  onCleanup(() => {
    mounted = false;
  });

  createEffect(async () => {
    const qid = props.question?.$id;
    if (!qid) {
      setActive(false);
      setNote(undefined);
      return;
    }

    try {
      const fav = await getFavorite(qid);
      if (!mounted) return;
      if (fav) {
        setActive(true);
        setNote(fav.note);
      } else {
        setActive(false);
        setNote(undefined);
      }
    } catch (err) {
      console.error("failed to read favorite:", err);
    }
  });

  const handleAdd = async (e: MouseEvent) => {
    e.stopPropagation();
    if (!props.question) return;
    const userNote =
      window.prompt("أضف ملاحظة للسؤال (اختياري):", note() ?? "") ?? undefined;
    try {
      await addFavoriteForQuestion(props.question, userNote, props.userAnswer);
      setNote(userNote);
      setActive(true);
      toast.success("تمت الإضافة إلى المفضلة");
    } catch {
      toast.error("فشل الحفظ");
    }
  };

  const handleRemove = async (e: MouseEvent) => {
    e.stopPropagation();
    const qid = props.question?.$id;
    if (!qid) return;
    try {
      await removeFavorite(qid);
      setActive(false);
      setNote(undefined);
      toast.success("أزيل من المفضلة");
    } catch {
      toast.error("فشل الحذف");
    }
  };

  const handleEditNote = async (e: MouseEvent) => {
    e.stopPropagation();
    const qid = props.question?.$id;
    if (!qid) return;
    const userInput = window.prompt("حرّر ملاحظتك:", note());
    if (userInput === null) return;
    try {
      await updateFavoriteNote(qid, userInput.trim());
      setNote(userInput.trim());
      toast.success("تم تحديث الملاحظة");
    } catch {
      toast.error("فشل التحديث");
    }
  };

  return (
    <div class={props.class} on:click={(e) => e.stopPropagation()}>
      <Show
        when={active()}
        fallback={
          <button
            on:click={handleAdd}
            class="relative flex items-center justify-center rounded-full p-2 transition hover:scale-105"
            aria-label="Save question to favorites"
          >
            <svg
              class="absolute w-full overflow-visible"
              viewBox="0 0 24 24"
              fill="none"
              width="18"
              height="18"
            >
              <circle
                class="text-main origin-center animate-[circle_.3s_forwards]"
                cx="4"
                cy="4"
                r="11.5"
                fill="transparent"
                stroke-width="0"
                stroke="currentColor"
              />
            </svg>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path
                d="m12 5.184-.808-.771-.004-.004C11.065 4.299 8.522 2.003 6 2.003c-3.736 0-6 2.558-6 6.677 0 4.47 5.471 9.848 10 13.079.602.43 1.187.82 1.74 1.167A.497.497 0 0 0 12 23v-.003c.09 0 .182-.026.26-.074C16.977 19.97 24 13.737 24 8.677 24 4.557 21.743 2 18 2c-2.569 0-5.166 2.387-5.192 2.413L12 5.184zm-.002 15.525c2.071-1.388 4.477-3.342 6.427-5.47C20.72 12.733 22 10.401 22 8.677c0-1.708-.466-2.855-1.087-3.55C20.316 4.459 19.392 4 18 4c-.726 0-1.63.364-2.5.9-.67.412-1.148.82-1.266.92-.03.025-.037.031-.019.014l-.013.013L12 7.949 9.832 5.88a10.08 10.08 0 0 0-1.33-.977C7.633 4.367 6.728 4.003 6 4.003c-1.388 0-2.312.459-2.91 1.128C2.466 5.826 2 6.974 2 8.68c0 1.726 1.28 4.058 3.575 6.563 1.948 2.127 4.352 4.078 6.423 5.466z"
                fill="currentColor"
                fill-rule="evenodd"
                clip-rule="evenodd"
              />
            </svg>
          </button>
        }
      >
        <div class="flex">
          <button
            on:click={handleRemove}
            class="text-main flex items-center justify-center rounded-full p-2 transition hover:scale-105"
            aria-label="Remove from favorites"
          >
            <svg
              class="origin-center animate-[scale_.35s_ease-in-out_forwards]"
              viewBox="0 0 24 24"
              fill="none"
              width="18"
              height="18"
            >
              <path
                d="M12 23a.496.496 0 0 1-.26-.074C7.023 19.973 0 13.743 0 8.68c0-4.12 2.322-6.677 6.058-6.677 2.572 0 5.108 2.387 5.134 2.41l.808.771.808-.771C12.834 4.387 15.367 2 17.935 2 21.678 2 24 4.558 24 8.677c0 5.06-7.022 11.293-11.74 14.246a.496.496 0 0 1-.26.074V23z"
                fill="currentColor"
              />
            </svg>
          </button>

          <button
            on:click={handleEditNote}
            title={note() ? "تعديل الملاحظة" : "إضافة ملاحظة"}
            class="dark:text-ink-dark text-ink-soft-light hover:text-ink-light"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18"
              height="18"
              viewBox="0 0 24 24"
            >
              <path
                fill="currentColor"
                d="M6 22q-.825 0-1.412-.587T4 20V4q0-.825.588-1.412T6 2h7.175q.4 0 .763.15t.637.425l4.85 4.85q.275.275.425.638t.15.762V20q0 .825-.587 1.413T18 22zm7-14q0 .425.288.713T14 9h4l-5-5z"
              />
            </svg>
          </button>
        </div>
      </Show>
    </div>
  );
}
