/**
 * AdminEditPanel.tsx
 * ───────────────────
 * لوحة تعديل/حذف السؤال الحالي — تظهر فقط للأدمن داخل واجهة حل الكويز.
 * تُعيد استخدام نفس ManualForm و SectionSelectors المستخدمة في الداشبورد،
 * ونفس دوال updateQuestion / deleteQuestion — لا منطق جديد، فقط واجهة وصول
 * سريعة من داخل الكويز عندما يلاحظ الأدمن خطأ في السؤال أثناء الحل.
 */

import { createResource, createSignal, Show } from "solid-js";
import { getSections } from "../../shared/services/sections";
import { getQuestion, deleteQuestion } from "../services/questions";
import type { QuestionUI } from "../services/types";
import { ManualForm } from "./ManualForm";
import { db, type Question } from "../services/local/indexeddb";
import toast from "solid-toast";
import { useUser } from "../../shared/context/user";

export default function AdminEditPanel(props: {
  open: boolean;
  onClose: () => void;
  subjectId: string;
  question: Question | null | undefined;
  // يُستدعى بعد أي تعديل أو حذف فعلي لإعادة مزامنة قائمة الأسئلة المعروضة
  onQuestionChanged: () => void;
}) {
  const [sections] = createResource(() => props.subjectId, getSections);
  const [deleting, setDeleting] = createSignal(false);
  const { can } = useUser();

  const handleDelete = async () => {
    const q = props.question;
    if (!q) return;
    if (
      !confirm(
        "هل تريد حذف هذا السؤال نهائياً من قاعدة البيانات؟ لا يمكن التراجع عن هذا الإجراء.",
      )
    )
      return;

    setDeleting(true);
    const res = await deleteQuestion(props.subjectId, q.$id);
    setDeleting(false);

    if (res?.error) return;

    // ✅ إزالة فورية من الكاش المحلي كي يختفي السؤال من الكويز مباشرة
    await db.questions.delete(q.$id);
    props.onQuestionChanged();
    props.onClose();
  };

  // ManualForm يستدعي updateQuestion داخلياً وينادي onComplete بعد الحفظ
  const handleSaved = async () => {
    const q = props.question;
    if (!q) return;

    const fresh: QuestionUI | null = await getQuestion(props.subjectId, q.$id);
    if (fresh) {
      // ✅ نحافظ على حقل subject المحلي (غير موجود في QuestionUI) ونحدّث الباقي
      const merged: Question = { ...q, ...fresh, subject: q.subject };
      await db.questions.put(merged);
    }

    props.onQuestionChanged();
    toast.success("تم تحديث السؤال في الكويز ✏️");
    props.onClose();
  };

  return (
    <Show when={props.open}>
      {/* Overlay */}
      <div
        class="fixed inset-0 z-[300] bg-black/40 backdrop-blur-sm"
        onClick={props.onClose}
      />

      {/* Panel */}
      <div
        class="fixed right-0 bottom-0 left-0 z-[301] flex max-h-[90dvh] flex-col overflow-y-auto rounded-t-3xl bg-surface-light shadow-2xl dark:bg-base-dark"
        dir="rtl"
      >
        {/* Header */}
        <div class="sticky top-0 z-10 flex items-center justify-between border-b border-line-light bg-surface-light px-5 py-4 dark:border-line-dark dark:bg-base-dark">
          <div class="flex items-center gap-2">
            <span class="text-xl">✏️</span>
            <h3 class="font-bold">تعديل السؤال (أدمن)</h3>
          </div>
          <button
            onClick={props.onClose}
            class="text-ink-muted-light hover:text-ink-soft-light dark:hover:text-ink-dark"
          >
            ✕
          </button>
        </div>

        <div class="space-y-4 p-5">
          <Show
            when={sections() && props.question}
            fallback={
              <p class="text-center text-sm text-ink-muted-light">
                جاري تحميل البيانات...
              </p>
            }
          >
            <ManualForm
              subjectId={props.subjectId}
              sections={sections()!}
              editQuestion={props.question as unknown as QuestionUI}
              onComplete={handleSaved}
            />
          </Show>

          <Show when={can("quiz", props.subjectId, "manage")}>
            <button
              onClick={handleDelete}
              disabled={deleting()}
              class="w-full rounded-2xl bg-red-50 py-3 text-sm font-bold text-red-600 transition hover:bg-red-100 disabled:opacity-50 dark:bg-red-900/20"
            >
              {deleting() ? "جاري الحذف..." : "حذف السؤال نهائياً 🗑️"}
            </button>
          </Show>
        </div>
      </div>
    </Show>
  );
}
