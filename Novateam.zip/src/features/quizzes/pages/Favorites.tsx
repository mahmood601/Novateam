import { createSignal, onMount, For, Show, Setter, createResource } from "solid-js";
import { useParams } from "@solidjs/router";
import type { Favorite } from "../services/local/indexeddb";
import {
  getFavorites,
  getSeasonName,
  getSubjectsByYear,
  getYearName,
  getPassageById,
  syncPassagesOfflineFirst,
  removeFavorite,
  updateFavoriteNote,
} from "../services/local/indexeddb";
import toast from "solid-toast";
import Loading from "../../shared/components/Loading";
import LeftArrow from "../../shared/components/Icons/LeftArrow";

export default function FavoritesPage() {
  const [favorites, setFavorites] = createSignal<Favorite[]>([]);
  const [loading, setLoading] = createSignal(true);
  const subject = useParams().subject;

  async function load(subject?: string) {
    setLoading(true);
    try {
      const favs = await getFavorites(subject);
      setFavorites(favs.sort((a, b) => b.savedAt - a.savedAt));
    } catch (err) {
      console.error("load favorites:", err);
      toast.error("فشل تحميل المفضلات");
    } finally {
      setLoading(false);
    }
  }

  onMount(() => {
    load(subject);
  });

  return (
    <div class="bg-main-light dark:bg-main-dark text-main-dark dark:text-main-light relative p-6 h-auto min-h-fit ">
      <div class="fixed top-2 left-1/2 w-[95%] -translate-x-1/2 z-20">
        <div class="backdrop-blur-2xl  rounded-2xl px-4 py-2 flex items-center justify-between">
          <button type="button" onClick={() => history.back()} aria-label="رجوع" class="p-1">
        <LeftArrow />
          </button>

          <h1 class="text-2xl font-bold">المفضلة</h1>

          <button
        type="button"
        class="bg-main rounded px-3 py-1 text-white"
        onClick={() => load()}
        aria-label="تحديث المفضلات"
          >
        تحديث
          </button>
        </div>
      </div>
      <Show when={!loading()} fallback={<Loading />}>
        <Show
          when={favorites().length > 0}
          fallback={<p class="py-20 text-center">لا توجد عناصر في المفضلة</p>}
        >
          <ul class="pt-[70px] pb-[20px] space-y-4">
            <For each={favorites()}>
              {(fav) => <FavBox fav={fav} setFavorites={setFavorites} />}
            </For>
          </ul>
        </Show>
      </Show>
    </div>
  );
}

function FavBox(props: { fav: Favorite; setFavorites: Setter<Favorite[]> }) {
     const [yearKey, setYearKey] = createSignal<string | null>(
    localStorage.getItem("year"),
  ); 

  
  const [yearSubjects] = createResource(
      () => yearKey(),
      async (year) => {
        if (!year) return [];
        return getSubjectsByYear(year);
      },
    );
  const snapshot = props.fav.snapshot;


  // resolve season name (ensure we set a string, not an object)
  const [yearName] = createResource(
     () => snapshot?.year_id,
     (yearId) => getYearName(snapshot?.subject, yearId ?? null),
   );
 
   const [seasonName] = createResource(
     () => snapshot?.season_id,
     (seasonId) => getSeasonName(snapshot?.subject, seasonId ?? null),
   );

  // ✅ تُفتح المقالة فقط عند الضغط على tag "مقالة"
  const [passageOpen, setPassageOpen] = createSignal(false);
  const [passage] = createResource(
    () => (passageOpen() && snapshot?.passage_id ? snapshot.passage_id : null),
    async (passageId) => {
      await syncPassagesOfflineFirst(snapshot?.subject ?? "");
      return getPassageById(passageId);
    },
  );
 

  const handleRemove = async (qid: string) => {
    if (!confirm("هل تريد إزالة هذا السؤال من المفضلة؟")) return;
    try {
      await removeFavorite(qid);
      props.setFavorites((prev) => prev.filter((p) => p.questionId !== qid));
      toast.success("أزيل من المفضلة");
    } catch (err) {
      console.error("removeFavorite:", err);
      toast.error("فشل الحذف");
    }
  };

  const handleEditNote = async (fav: Favorite) => {
    const current = fav.note ?? "";
    const input = window.prompt("حرّر الملاحظة:", current);
    if (input === null) return; // cancel -> keep old note
    const newNote = input.trim();
    try {
      await updateFavoriteNote(fav.questionId, newNote);
      props.setFavorites((prev) =>
        prev.map((p) =>
          p.questionId === fav.questionId ? { ...p, note: newNote } : p,
        ),
      );
      toast.success("تم تحديث الملاحظة");
    } catch (err) {
      console.error("updateFavoriteNote:", err);
      toast.error("فشل التحديث");
    }
  };

  return (
    <li class="bg-darker-light-1 dark:bg-lighter-dark-1 rounded-md p-4 shadow-sm">
      <div class="flex flex-col">
        <div>
          <div class="mb-3 flex flex-col text-center">
            <span class="text-gray-500 flex-1 text-xs">
              {new Date(props.fav.savedAt).toLocaleString()}
            </span>
            <span dir="rtl" class="text-gray-500 flex-1 text-xs">
              {yearName()} - {seasonName()}
            </span>
          </div>

          <p class="mb-3 text-right font-semibold" dir="rtl">
            {props.fav.snapshot?.question ?? "سؤال محفوظ"}
          </p>

          {/* Badge مقالة — قابل للضغط لعرض/إخفاء نص الحالة السريرية */}
          <Show when={snapshot?.passage_id}>
            <button
              type="button"
              onClick={() => setPassageOpen((v) => !v)}
              class="mb-2 inline-block rounded-full bg-main/10 px-2 py-0.5 text-[10px] font-bold text-main transition hover:bg-main/30 dark:bg-main/10 dark:text-main/70 dark:hover:bg-main/30"
            >
              📋 مقالة {passageOpen() ? "▲" : "▼"}
            </button>
          </Show>

          <Show when={passageOpen() && snapshot?.passage_id}>
            <div
              dir="rtl"
              class="mb-3 rounded-xl border border-main/30 bg-main/10 p-3 text-sm dark:border-main/40 dark:bg-main/10"
            >
              <Show
                when={passage()}
                fallback={<p class="text-xs text-gray-400">جاري التحميل...</p>}
              >
                <p class="whitespace-pre-wrap text-right text-gray-700 dark:text-gray-300">
                  {passage()?.content}
                </p>
              </Show>
            </div>
          </Show>
          <For each={snapshot?.options.filter((option) => option)}>
            {(option, index) => (
              <p
                dir="rtl"
                classList={{
                  "bg-main rounded-md p-1 text-white":
                    snapshot?.correctIndex == index(),
                  "bg-red-500 rounded-md p-1 text-white":
                    snapshot?.userAnswer == option &&
                    snapshot?.correctIndex != index(),
                  "my-1 text-right ": true,
                }}
              >
                {index() + 1}. {option}
              </p>
            )}
          </For>
          <Show
            when={props.fav.note}
            fallback={
              <p dir="rtl" class="my-4 text-center text-sm text-gray-500">
                بدون ملاحظة
              </p>
            }
          >
            <p class="text-main my-4 text-center text-sm whitespace-pre-wrap">
              {props.fav.note}
            </p>
          </Show>
        </div>

        <div class="flex justify-around">
          <button
            class="bg-main text-main-light rounded px-3 py-1 text-sm"
            onClick={() => handleRemove(props.fav.questionId)}
          >
            إزالة
          </button>

          <button
            class="bg-main text-main-light rounded px-3 py-1 text-sm"
            onClick={() => handleEditNote(props.fav)}
          >
            تعديل الملاحظة
          </button>
        </div>
      </div>
    </li>
  );
}
