import { createComputed, createEffect, createMemo, createResource, createSignal, For, Match, Show, Suspense, Switch } from "solid-js";
import { useLocation, useNavigate, useParams, useSearchParams } from "@solidjs/router";
import { supabase } from "../../shared/services/supabase";
import { getSections } from "../../shared/services/sections";
import type { QuestionUI, Section } from "../services/types";
import { fetchUserNames } from "../../shared/services/user";
import { useUser } from "../../shared/context/user";
import toast from "solid-toast";
import { QuestionCard } from "../components/QuestionCard";
import { SmartImporter } from "../components/SmartImporter";
import { ManualForm } from "../components/ManualForm";
import { PassageManager } from "../components/PassageManager";
import { isAdminRole } from "../../shared/lib/roles";
import { BulkActionBar } from "../components/BulkActionBar";
import { SuggestionsManager } from "../components/SuggestionsManager";


export type qModeT = "insert" | "edit" | "delete" | "";
export { ManualForm } from "../components/ManualForm";
export { SectionSelectors } from "../components/SectionSelectors";

const PAGE_SIZE = 10;

export default function QuizEditor() {
    const params = useParams();
    const location = useLocation();
    const { user, can } = useUser();
    const navigate = useNavigate();

    const subjectId = () => params.subject;


    const [searchParams, setSearchParams] = useSearchParams();
    const isInFavorite = () => location.pathname.includes("favorite");

    const [page, setPage] = createSignal(0);
    const [mode, setMode] = createSignal<"smart" | "manual">("smart");
    const [showAdd, setShowAdd] = createSignal(false);
    const [editTarget, setEditTarget] = createSignal<QuestionUI | null>(null);
    const [mainTab, setMainTab] = createSignal<"questions" | "passages" | "suggestions">("questions");

    const [selectedIds, setSelectedIds] = createSignal<Set<string>>(new Set<string>());
    const [selectionMode, setSelectionMode] = createSignal(false);

    const toggleSelect = (id: string) => {
        setSelectedIds((prev) => {
            const next = new Set(prev);
            if (next.has(id)) {
                next.delete(id);
            } else {
                next.add(id);
            }
            if (next.size === 0) setSelectionMode(false);
            return next;
        });
    };

    const clearSelection = () => {
        setSelectedIds(new Set<string>());
        setSelectionMode(false);
    };

    const toggleSelectAll = () => {
        const currentIds = data()?.questions.map((q) => q.$id) ?? [];
        const allSelected = currentIds.every((id) => selectedIds().has(id));
        setSelectedIds((prev) => {
            const next = new Set(prev);
            if (allSelected) {
                currentIds.forEach((id) => next.delete(id));
                if (next.size === 0) setSelectionMode(false);
            } else {
                currentIds.forEach((id) => next.add(id));
            }
            return next;
        });
    };

    const filterSeasonId = () => (searchParams.season ? Number(searchParams.season) : null);
    const filterYearId = () => (searchParams.year ? Number(searchParams.year) : null);
    // "" = all, otherwise draft | pending | published (staff only ever see non-published rows)
    const filterStatus = () => (typeof searchParams.status === "string" ? searchParams.status : "");
    const canPublish = () => can("quiz", subjectId(), "publish");

    const [sections] = createResource(() => getSections(subjectId() ?? ""));

    const [data, { refetch }] = createResource(
        () => ({
            p: page(),
            seasonId: filterSeasonId(),
            yearId: filterYearId(),
            status: filterStatus(),
        }),
        async ({ p, seasonId, yearId, status }) => {
            let query = supabase
                .from("questions")
                .select(
                    `*, image_url, season:sections!season_id(id,name,value),
               year:sections!year_id(id,name,value)`,
                    { count: "exact" },
                )
                .eq("subject_id", subjectId() ?? "");

            if (seasonId) query = query.eq("season_id", seasonId);
            if (yearId) query = query.eq("year_id", yearId);
            if (status) query = query.eq("status", status);

            const { data: rows, count, error } = await query
                .range(p * PAGE_SIZE, p * PAGE_SIZE + PAGE_SIZE - 1)
                .order("created_at", { ascending: false });

            if (error) {
                toast.error(error.message);
                return {
                    questions: [],
                    total: 0,
                    namesMap: new Map<string, string>(),
                    passagesMap: new Map<string, string>(),
                };
            }

            const questions: QuestionUI[] = (rows ?? []).map((row: any) => ({
                $id: row.id,
                subject_id: row.subject_id,
                season_id: row.season_id,
                year_id: row.year_id,
                question: row.question,
                explanation: row.explanation,
                options: row.options ?? [],
                correctIndex: row.correct_index,
                user_id: row.created_by,
                passage_id: row.passage_id,
                seasonName: row.season?.name,
                seasonValue: row.season?.value,
                yearName: row.year?.name,
                yearValue: row.year?.value,
                image_url: row.image_url,
                status: row.status ?? "published",
            }));

            const userIds = questions.map((q) => q.user_id).filter(Boolean) as string[];
            const namesMap = await fetchUserNames(userIds);

            const passageIds = [...new Set(questions.map((q) => q.passage_id).filter(Boolean))] as string[];
            const passagesMap = new Map<string, string>();
            if (passageIds.length > 0) {
                const { data: passageRows } = await supabase
                    .from("passages")
                    .select("id, content")
                    .in("id", passageIds);
                (passageRows ?? []).forEach((r: any) => passagesMap.set(r.id, r.content));
            }

            return { questions, total: count ?? 0, namesMap, passagesMap };
        },
    );

    const openEdit = (q: QuestionUI) => {
        setEditTarget(q);
        setMode("manual");
        setShowAdd(true);
        window.scrollTo({ top: 0, behavior: "smooth" });
    };

    const onFormComplete = () => {
        setShowAdd(false);
        setEditTarget(null);
        refetch();
    };

    createComputed(() => {
        if (user() && !isAdminRole(user()?.role)) {
            navigate("/", { replace: true });
        }
    });


    return (
        <Show when={!isInFavorite()}>
            <div class="min-h-screen bg-base-light px-5 pt-22 pb-10 dark:bg-base-dark" dir="rtl">
                <div class="mx-auto mb-8 flex max-w-4xl items-center justify-between rounded-[2.5rem] bg-surface-light/80 p-6 shadow-sm backdrop-blur-md dark:bg-surface-dark/80">
                    <div>
                        <h1 class="text-2xl font-black text-ink-light dark:text-ink-dark">
                            إدارة المحتوى
                        </h1>
                        <div class="mt-3 flex items-center gap-1">
                            <p class="text-sm text-ink-muted-light">
                                المادة: <span class="font-bold text-ink-soft-light dark:text-ink-soft-dark">{subjectId()}</span>
                            </p>
                        </div>
                    </div>
                    <div class="flex flex-col-reverse items-center gap-2 lg:flex-row">
                        <Show when={canPublish()}>
                        <button
                            onClick={() => {
                                if (selectionMode()) {
                                    clearSelection();
                                } else {
                                    setSelectionMode(true);
                                }
                            }}
                            class={`flex h-7 w-7 items-center justify-center rounded-full text-lg transition-all ${selectionMode()
                                    ? "bg-cyan-500 text-white shadow-lg"
                                    : "bg-chip-light text-ink-soft-light hover:bg-darker-light-2 dark:bg-chip-dark dark:text-ink-soft-dark"
                                }`}
                            title={selectionMode() ? "إلغاء وضع التحديد" : "تحديد متعدد"}
                        >
                            {selectionMode() ? "✕" : "☑"}
                        </button>
                        </Show>
                        <button
                            onClick={() => {
                                setEditTarget(null);
                                setShowAdd(!showAdd());
                            }}
                            class={`flex h-14 w-14 items-center justify-center rounded-full text-2xl text-white shadow-lg transition-all ${showAdd()
                                    ? "rotate-45 bg-slate-800"
                                    : "bg-gradient-to-tr from-cyan-400 to-fuchsia-500"
                                }`}
                        >
                            +
                        </button>
                    </div>
                </div>

                <Show when={mainTab() === "questions"}>
                    <Show when={showAdd()}>
                        <div class="mb-12 rounded-[3rem] border-4 border-cyan-50 bg-surface-light p-8 shadow-xl dark:border-line-dark dark:bg-surface-dark">
                            <Show when={!editTarget()}>
                                <div class="mx-auto mb-8 flex w-fit rounded-full bg-chip-light p-1 dark:bg-base-dark">
                                    <button
                                        onClick={() => setMode("smart")}
                                        class={`rounded-full px-8 py-2 font-bold transition-all ${mode() === "smart" ? "bg-surface-light text-cyan-600 shadow-sm dark:bg-chip-dark" : "text-ink-muted-light"}`}
                                    >
                                        🚀 ذكي
                                    </button>
                                    <button
                                        onClick={() => setMode("manual")}
                                        class={`rounded-full px-8 py-2 font-bold transition-all ${mode() === "manual" ? "bg-surface-light text-fuchsia-600 shadow-sm dark:bg-chip-dark" : "text-ink-muted-light"}`}
                                    >
                                        ✍️ يدوي
                                    </button>
                                </div>
                            </Show>

                            <Switch>
                                <Match when={mode() === "smart" && !editTarget()}>
                                    <SmartImporter
                                        subjectId={subjectId() ?? ""}
                                        sections={sections() ?? []}
                                        onComplete={onFormComplete}
                                    />
                                </Match>
                                <Match when={mode() === "manual" || !!editTarget()}>
                                    <ManualForm
                                        subjectId={subjectId() ?? ""}
                                        sections={sections() ?? []}
                                        editQuestion={editTarget()}
                                        onComplete={onFormComplete}
                                    />
                                </Match>
                            </Switch>
                        </div>
                    </Show>
                </Show>

                <Show when={sections()}>
                    <div class="mx-auto mb-6 max-w-4xl">
                        <div class="rounded-[2rem] bg-surface-light p-4 shadow-sm dark:bg-surface-dark">
                            <p class="mb-3 text-xs font-bold text-ink-muted-light">
                                🔍 تصفية الأسئلة
                            </p>
                            <div class="grid grid-cols-2 gap-3">
                                <div class="flex flex-col gap-1">
                                    <label class="text-xs font-bold text-ink-soft-light dark:text-ink-muted-dark">
                                        الفصل
                                    </label>
                                    <select
                                        class="rounded-2xl bg-base-light p-3 text-sm outline-none focus:ring-2 focus:ring-cyan-300 dark:bg-base-dark dark:text-ink-dark"
                                        onChange={(e) => {
                                            setPage(0);
                                            setSearchParams({ season: e.currentTarget.value || undefined });
                                        }}
                                    >
                                        <option value="">الكل</option>
                                        <For each={sections()?.filter((s: Section) => s.type === "season").sort((a, b) => +a.value - +b.value)}>
                                            {(s) => (
                                                <option value={s.id} selected={filterSeasonId() === s.id}>
                                                    {s.name}
                                                </option>
                                            )}
                                        </For>
                                    </select>
                                </div>
                                <div class="flex flex-col gap-1">
                                    <label class="text-xs font-bold text-ink-soft-light dark:text-ink-muted-dark">
                                        السنة
                                    </label>
                                    <select
                                        class="rounded-2xl bg-base-light p-3 text-sm outline-none focus:ring-2 focus:ring-cyan-300 dark:bg-base-dark dark:text-ink-dark"
                                        onChange={(e) => {
                                            setPage(0);
                                            setSearchParams({ year: e.currentTarget.value || undefined });
                                        }}
                                    >
                                        <option value="">الكل</option>
                                        <For each={sections()?.filter((s: Section) => s.type === "year").sort((a, b) => +b.value - +a.value)}>
                                            {(y) => (
                                                <option value={y.id} selected={filterYearId() === y.id}>
                                                    {y.name}
                                                </option>
                                            )}
                                        </For>
                                    </select>
                                </div>
                            </div>
                            <div class="mt-3 flex flex-col gap-1">
                                <label class="text-xs font-bold text-ink-soft-light dark:text-ink-muted-dark">
                                    الحالة
                                </label>
                                <select
                                    class="rounded-2xl bg-base-light p-3 text-sm outline-none focus:ring-2 focus:ring-cyan-300 dark:bg-base-dark dark:text-ink-dark"
                                    onChange={(e) => {
                                        setPage(0);
                                        setSearchParams({ status: e.currentTarget.value || undefined });
                                    }}
                                >
                                    <option value="" selected={filterStatus() === ""}>الكل</option>
                                    <option value="pending" selected={filterStatus() === "pending"}>⏳ بانتظار المراجعة</option>
                                    <option value="published" selected={filterStatus() === "published"}>منشور</option>
                                    <option value="draft" selected={filterStatus() === "draft"}>مسودة</option>
                                </select>
                            </div>
                            <Show when={filterSeasonId() || filterYearId() || filterStatus()}>
                                <button
                                    onClick={() => {
                                        setPage(0);
                                        setSearchParams({ season: undefined, year: undefined, status: undefined });
                                    }}
                                    class="mt-2 text-xs text-red-400 underline"
                                >
                                    ✕ إلغاء الفلترة
                                </button>
                            </Show>
                        </div>
                    </div>
                </Show>

                <div class="mx-auto mb-6 flex w-fit max-w-4xl rounded-full bg-chip-light p-1 dark:bg-base-dark">
                    <button
                        onClick={() => setMainTab("questions")}
                        class={`rounded-full px-4 py-2 text-sm font-bold transition-all ${mainTab() === "questions" ? "bg-surface-light text-cyan-600 shadow-sm dark:bg-chip-dark" : "text-ink-muted-light"}`}
                    >
                        📋 الأسئلة
                    </button>
                    <button
                        onClick={() => setMainTab("passages")}
                        class={`rounded-full px-4 py-2 text-sm font-bold transition-all ${mainTab() === "passages" ? "bg-surface-light text-amber-600 shadow-sm dark:bg-chip-dark" : "text-ink-muted-light"}`}
                    >
                        🗒️ المقالات
                    </button>
                    <Show when={canPublish()}>
                        <button
                            onClick={() => setMainTab("suggestions")}
                            class={`rounded-full px-4 py-2 text-sm font-bold transition-all ${mainTab() === "suggestions" ? "bg-surface-light text-green-600 shadow-sm dark:bg-chip-dark" : "text-ink-muted-light"}`}
                        >
                            💡 المقترحات
                        </button>
                    </Show>
                </div>

                <div class="mx-auto max-w-4xl pb-12">
                    <Suspense fallback={<div class="animate-pulse p-10 text-center text-ink-muted-light">...</div>}>
                                 <Show when={mainTab() === "passages"}>
                        <PassageManager subjectId={subjectId() ?? ""} />
                    </Show>

                    <Show when={mainTab() === "suggestions" && canPublish()}>
                        <SuggestionsManager subjectId={subjectId() ?? ""} sections={sections() ?? []} onApplied={refetch} />
                    </Show>

                    <Show when={mainTab() === "questions"}>
                        <Suspense fallback={<div class="animate-pulse p-20 text-center text-ink-muted-light">جاري تحميل الأسئلة... 🧬</div>}>
                            <Show
                                when={(data()?.total ?? 0) > 0}
                                fallback={
                                    <p class="py-20 text-center text-ink-muted-light">
                                        {filterSeasonId() || filterYearId()
                                            ? "لا توجد أسئلة لهذا الفلتر 🔍"
                                            : "لا توجد أسئلة بعد 🎯"}
                                    </p>
                                }
                            >
                                <p class="mb-4 text-sm text-ink-muted-light">
                                    إجمالي:{" "}
                                    <span class="font-bold text-ink-soft-light dark:text-ink-soft-dark">
                                        {data()?.total}
                                    </span>
                                    <Show when={filterSeasonId() || filterYearId()}>
                                        <span class="mr-2 text-cyan-500">(مُفلترة)</span>
                                    </Show>
                                    <Show when={selectionMode()}>
                                        <button
                                            onClick={toggleSelectAll}
                                            class="mr-3 text-xs font-bold text-cyan-600 underline"
                                        >
                                            {(data()?.questions ?? []).every((q) => selectedIds().has(q.$id))
                                                ? "إلغاء تحديد الصفحة"
                                                : `تحديد الصفحة (${data()?.questions.length})`}
                                        </button>
                                        <Show when={selectedIds().size > 0}>
                                            <span class="mr-1 text-xs font-bold text-cyan-700">
                                                — {selectedIds().size} محدد إجمالاً
                                            </span>
                                        </Show>
                                    </Show>
                                </p>

                                <div class="mb-10 grid gap-4">
                                    <For each={data()?.questions}>
                                        {(q, i) => (
                                            <QuestionCard
                                                question={q}
                                                index={page() * PAGE_SIZE + i() + 1}
                                                subjectId={subjectId() ?? ""}
                                                namesMap={data()?.namesMap ?? new Map()}
                                                passagesMap={data()?.passagesMap ?? new Map()}
                                                onRefetch={refetch}
                                                onEdit={openEdit}
                                                isSelected={selectedIds().has(q.$id)}
                                                onToggleSelect={toggleSelect}
                                                selectionMode={selectionMode()}
                                            />
                                        )}
                                    </For>
                                </div>

                                <Show when={(data()?.total ?? 0) > PAGE_SIZE}>
                                    <div class="mt-12 flex flex-wrap justify-center gap-2 pb-12">
                                        <For each={Array.from({ length: Math.ceil((data()?.total ?? 0) / PAGE_SIZE) })}>
                                            {(_, i) => (
                                                <button
                                                    onClick={() => {
                                                        setPage(i());
                                                        window.scrollTo({ top: 0, behavior: "smooth" });
                                                    }}
                                                    class={`h-8 w-8 rounded-full p-1 text-sm font-bold transition-all ${page() === i()
                                                            ? "scale-110 bg-cyan-500 text-white"
                                                            : "bg-surface-light text-ink-muted-light shadow-sm hover:bg-base-light"
                                                        }`}
                                                >
                                                    {i() + 1}
                                                </button>
                                            )}
                                        </For>
                                    </div>
                                </Show>
                            </Show>
                        </Suspense>
                    </Show>
                    </Suspense>
   
                </div>
            </div>

            <Show when={selectedIds().size > 0}>
                <BulkActionBar
                    selectedIds={selectedIds()}
                    sections={sections() ?? []}
                    subjectId={subjectId() ?? ""}
                    onClear={clearSelection}
                    onComplete={() => {
                        clearSelection();
                        refetch();
                    }}
                />
            </Show>
        </Show>
    );
}