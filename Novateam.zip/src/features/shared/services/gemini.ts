/**
 * gemini.ts
 * ─────────
 * يدير إرسال الطلبات لـ Gemini عبر Supabase Edge Function آمنة
 * ❌ لا يوجد أي API Key هنا — كل المفاتيح على الـ Server
 */

import { supabase } from "./supabase";

export type GeminiResult =
  | { ok: true; text: string }
  | {
      ok: false;
      reason: "no_key" | "nova_depleted" | "error";
      message: string;
      userLimit?: boolean;
    };

// ─── استدعاء الـ Supabase Edge Function (المفتاح مخفي في السيرفر) ───────────

async function callGeminiViaEdge(
  systemContext: string,
  history: { role: string; parts: { text: string }[] }[],
  userText: string,
): Promise<string> {
  const { data, error } = await supabase.functions.invoke("gemini-proxy", {
    body: { systemContext, history, userText },
  });

  if (error) {
    console.error("❌ Gemini Edge Error:", error);
    // FunctionsHttpError يحمل الرسالة الأصلية ضمن context.json() غالباً
    const message =
      (error as any)?.context?.error ?? error.message ?? "حدث خطأ غير معروف";
    throw new Error(message);
  }

  if (data?.error) {
    console.error("❌ Gemini Edge Error (payload):", data.error);
    throw new Error(data.error);
  }

  return data.text;
}

// ─── اختيار النموذج (يُحفظ محلياً) ───────────────────────────────────────────

export const GEMINI_MODEL_STORAGE_KEY = "gemini_model";
export const DEFAULT_GEMINI_MODEL = "gemini-3.5-flash-lite";

export function getSelectedGeminiModel(): string {
  try {
    return localStorage.getItem(GEMINI_MODEL_STORAGE_KEY) || DEFAULT_GEMINI_MODEL;
  } catch {
    return DEFAULT_GEMINI_MODEL;
  }
}

// نماذج لا تصلح للمحادثة النصية (صور/صوت/تضمين...) نخفيها من القائمة
const NON_CHAT_MODEL = /tts|image|imagen|embedding|live|audio|robotics|computer-use|aqa|veo/i;

/** يجلب النماذج المتاحة لمفتاح المستخدم (التي تدعم generateContent). */
export async function listGeminiModels(apiKey: string): Promise<string[]> {
  const ids: string[] = [];
  let pageToken = "";
  do {
    const url =
      `https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000&key=${encodeURIComponent(apiKey)}` +
      (pageToken ? `&pageToken=${encodeURIComponent(pageToken)}` : "");
    const res = await fetch(url);
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data?.error?.message ?? "تعذّر جلب قائمة النماذج");
    }
    for (const m of data.models ?? []) {
      const id = String(m.name ?? "").replace(/^models\//, "");
      if (
        id &&
        m.supportedGenerationMethods?.includes("generateContent") &&
        !NON_CHAT_MODEL.test(id)
      ) {
        ids.push(id);
      }
    }
    pageToken = data.nextPageToken ?? "";
  } while (pageToken);
  return ids.sort((a, b) => a.localeCompare(b));
}

// ─── استدعاء مباشر بمفتاح المستخدم الخاص (اختياري) ──────────────────────────

async function callGeminiWithUserKey(
  apiKey: string,
  systemContext: string,
  history: { role: string; parts: { text: string }[] }[],
  userText: string,
): Promise<string> {
  const GEMINI_MODEL = getSelectedGeminiModel();
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: systemContext }] },
        contents: [...history, { role: "user", parts: [{ text: userText }] }],
      }),
    },
  );

  const data = await res.json();

  if (!res.ok) {
    console.error("❌ Gemini User Key Error:", data);
    throw new Error(data?.error?.message ?? "حدث خطأ من خوادم Gemini");
  }

  return (
    data?.candidates?.[0]?.content?.parts?.[0]?.text ??
    "عذراً، لم أتمكن من معالجة الإجابة، حاول مجدداً."
  );
}

// ─── تحقق من الاستخدام اليومي لنوفا وزد العداد ──────────────────────────────

async function checkNovaUsage(): Promise<GeminiResult | null> {
  try {
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError) console.error("❌ Supabase Auth Error:", authError);

    if (!user) {
      await new Promise((r) => setTimeout(r, 1000));
      const {
        data: { user: retryUser },
      } = await supabase.auth.getUser();
      if (!retryUser)
        return {
          ok: false,
          reason: "nova_depleted",
          message: "يجب تسجيل الدخول أولاً",
          userLimit: false,
        };
    }

    const { data } = await supabase
      .from("ai_usage")
      .select("usage_count, last_reset_date")
      .eq("user_id", user!.id)
      .single();

    const today = new Date().toISOString().split("T")[0];
    const isNewDay = !data || data?.last_reset_date !== today;
    const currentCount = isNewDay ? 0 : (data.usage_count ?? 0);

    if (currentCount >= 10) {
      return {
        ok: false,
        reason: "nova_depleted",
        message: "لقد استنفدت الحد اليومي من الاستخدام",
        userLimit: true,
      };
    }

    return null;
  } catch {
    return null;
  }
}

async function incrementNovaUsage(): Promise<GeminiResult | null> {
  try {
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser();

    if (authError) console.error("❌ Supabase Auth Error:", authError);

    const { data, error } = await supabase.rpc("increment_ai_usage", {
      p_user_id: user!.id,
    });

    if (error) {
      console.error("❌ Supabase RPC Error:", error);
      return {
        ok: false,
        reason: "error",
        message: "خطأ في الاتصال بقاعدة البيانات",
        userLimit: false,
      };
    }

    if (!data.allowed) {
      return {
        ok: false,
        reason: "nova_depleted",
        message: data.reason,
        userLimit: data.reason === "user_limit",
      };
    }

    return null;
  } catch (err) {
    console.error("❌ Unknown Usage Check Error:", err);
    return {
      ok: false,
      reason: "error",
      message: "حدث خطأ أثناء التحقق من الرصيد",
      userLimit: false,
    };
  }
}

// ─── الدالة الرئيسية ──────────────────────────────────────────────────────────

export async function sendToGemini(
  systemContext: string,
  history: { role: string; parts: { text: string }[] }[],
  userText: string,
): Promise<GeminiResult> {
  // مفتاح المستخدم الخاص — أولوية قصوى (لا يزال آمناً لأنه مفتاحه هو)
  const userKey =
    typeof window !== "undefined"
      ? localStorage.getItem("gemini_api_key")
      : null;

  if (userKey) {
    try {
      const text = await callGeminiWithUserKey(
        userKey,
        systemContext,
        history,
        userText,
      );
      return { ok: true, text };
    } catch (e: any) {
      return {
        ok: false,
        reason: "error",
        message: `خطأ (مفتاحك): ${e.message}`,
      };
    }
  }

  // نوفا Key — عبر Edge Function آمنة
const check= await checkNovaUsage();
  if (check !== null) return check;

  try {
    const text = await callGeminiViaEdge(systemContext, history, userText);

    await incrementNovaUsage();
    return { ok: true, text };
  } catch (e: any) {
    return {
      ok: false,
      reason: "error",
      message: `خطأ (النظام): ${e.message}`,
    };
  }
}