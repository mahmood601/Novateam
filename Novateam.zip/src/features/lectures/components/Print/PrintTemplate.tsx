import './style.css'

export default function PrintTemplate(props: {subjectName: string, lectureNumber: string, lectureTitle: string, doctorName: string, year: string, semester: string, contentHtml: string}) {
  // props: { subjectName, lectureNumber, lectureTitle, doctorName, year, semester, contentHtml }

  return (
    <div class="print-page">
      {/* الغلاف */}
      <div class="page cover">
        <div class="cover-header">
          <div class="header-box">
            <div class="logos-box">
              <img class="nova-logo" src="/print/image1.png" alt="" />
              <div class="team-box">MEDICAL . TEAM</div>
            </div>
            <img class="tartous-logo" src="/print/image3.png" alt="" />
          </div>
        </div>
        <div>
          <div class="cover-circle"></div>
          <div class="cover-lecture-title">{props.subjectName}</div>
        </div>
        <div class="cover-footer">
          <div class="footer-box">
            <div class="footer-pages-number">
              <span class="footer-pages-text">عدد الصفحات</span>
              <span class="footer-pages-count total-pages"></span> {/* Paged.js بتملاها تلقائياً */}
            </div>
            <ul class="footer-info" dir="rtl">
              <li>{props.lectureNumber}. {props.lectureTitle}</li>
              <li>د. {props.doctorName}</li>
              <li>السنة {props.year} – الفصل {props.semester}</li>
            </ul>
          </div>
        </div>
      </div>

      {/* الهيدر/الفوتر كـ running elements — تتكرر تلقائياً بكل صفحة، والمحتوى يجي بينهم */}
      <div class="print-header">
        <img src="/print/image1.png" alt="" />
        <p dir="rtl">{props.subjectName}</p>
      </div>
      <div class="print-footer">
        <p dir="rtl">{props.lectureNumber}. {props.lectureTitle} - د. {props.doctorName} – السنة {props.year} الفصل {props.semester}</p>
      </div>

      {/* المحتوى الفعلي — Paged.js بتقسمه لصفحات تلقائياً */}
      <div class="page main" innerHTML={props.contentHtml} />
    </div>
  )
}