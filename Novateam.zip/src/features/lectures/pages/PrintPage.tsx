// src/pages/PrintPage.jsx
import { useParams } from "@solidjs/router"
import { createResource, Show } from "solid-js"
import { getLecture } from "@/features/shared/services/lecturesUpdates"
import { parseMarkdown } from "../lib/parseMarkdown"
import PrintTemplate from "@/features/lectures/components/Print/PrintTemplate"

export default function PrintPage() {
  const params = useParams()
  const [lecture] = createResource(() => params.id, getLecture)

  return (
    <Show when={lecture()?.data} fallback={<div>جار التحميل...</div>}>
      {(data) => {
        const [html] = createResource(() => data().content_json.raw, parseMarkdown)
        return (
          <PrintTemplate
            subjectName={data().subject_id}
            lectureNumber={data().section_id}
            doctorName={data().content_json.doctor_note}
            contentHtml={html() ?? ""}
          />
        )
      }}
    </Show>
  )
}