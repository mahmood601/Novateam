export default {
    plugins: {
        "@tailwindcss/postcss":{},
        "@csstools/postcss-oklab-function":{preserve: false},
    }
}